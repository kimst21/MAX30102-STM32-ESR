/* USER CODE BEGIN Header */
/**
  *******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  *******************************************************************************
  * @attention
  * - STM32 기반 펄스 옥시미터 프로그램
  * - MAX30102 센서를 사용하여 심박수(BPM)와 산소포화도(SpO2) 계산
  * - 계산된 데이터를 USB CDC로 전송
  *******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"                // 시스템 초기화 관련 기본 헤더
#include "i2c.h"                 // I2C 초기화 및 통신 관련 헤더
#include "usb_device.h"          // USB 디바이스 초기화 및 통신 관련 헤더
#include "gpio.h"                // GPIO 핀 제어 관련 헤더

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"              // 문자열 처리 라이브러리
#include "pulse_oximeter.h"      // MAX30102 센서와 관련된 함수 정의
#include <stdio.h>               // 표준 입출력 라이브러리
#include "usbd_cdc_if.h"         // USB CDC 인터페이스 헤더
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
volatile uint8_t pulseOximiterIntFlag = 0;   // MAX30102 데이터 준비 상태를 나타내는 플래그
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);               // 시스템 클럭 설정 함수
/* USER CODE BEGIN PFP */
int _write(int file, char *ptr, int len) {   // 표준 출력 리다이렉션 함수
    CDC_Transmit_FS((uint8_t*) ptr, len);    // USB CDC를 통해 데이터를 전송
    return len;
}
/* USER CODE END PFP */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 메인 함수 시작 전에 필요한 사용자 정의 설정 및 변수 선언 가능
  /* USER CODE END 1 */

  HAL_Init();                                // HAL 라이브러리 초기화
  SystemClock_Config();                      // 시스템 클럭 설정
  MX_GPIO_Init();                            // GPIO 초기화
  MX_I2C3_Init();                            // I2C3 초기화 (MAX30102와 통신)
  MX_USB_DEVICE_Init();                      // USB 디바이스 초기화

  /* USER CODE BEGIN 2 */
  FIFO_LED_DATA fifoLedData;                 // FIFO 데이터를 저장할 구조체
  long currentMillis = 0;                    // 현재 시간 기록
  long lastMillis = 0;                       // 마지막 데이터 출력 시간 기록
  /* USER CODE END 2 */

  /* MAX30102 센서 설정 */
  pulseOximeter_resetRegisters();            // 센서 레지스터 초기화
  pulseOximeter_initFifo();                  // FIFO 초기화
  pulseOximeter_setSampleRate(_100SPS);      // 샘플링 속도 설정 (100SPS)
  pulseOximeter_setPulseWidth(_411_US);      // 펄스 폭 설정 (411μs)
  pulseOximeter_setLedCurrent(RED_LED, 50);  // 적색 LED 전류 설정 (50mA)
  pulseOximeter_setLedCurrent(IR_LED, 5);    // 적외선 LED 전류 설정 (5mA)
  pulseOximeter_resetFifo();                 // FIFO 레지스터 초기화
  pulseOximeter_setMeasurementMode(SPO2);    // SPO2 측정 모드 설정

  currentMillis = HAL_GetTick();             // 현재 시간을 기록

  while (1)                                  // 메인 루프
  {
    if (PUSLE_OXIMETER_INTERRUPT == 1) {     // 인터럽트 기반 데이터 처리
      if (pulseOximiterIntFlag) {            // 데이터 준비 상태 플래그 확인
        pulseOximiterIntFlag = 0;            // 플래그 초기화
        fifoLedData = pulseOximeter_readFifo(); // FIFO 데이터 읽기
        pulseOximeter = pulseOximeter_update(fifoLedData); // BPM/SpO2 계산
        pulseOximeter_clearInterrupt();      // 인터럽트 클리어
      }
    } else {                                 // 폴링 기반 데이터 처리
      fifoLedData = pulseOximeter_readFifo(); // FIFO 데이터 읽기
      pulseOximeter = pulseOximeter_update(fifoLedData); // BPM/SpO2 계산
      pulseOximeter_resetFifo();             // FIFO 초기화
      HAL_Delay(10);                         // 10ms 대기
    }

    currentMillis = HAL_GetTick();           // 현재 시간 갱신
    if (currentMillis - lastMillis > 1000) { // 1초마다 데이터 출력
      pulseOximeter_displayData();           // 데이터 출력 (USB CDC)
      lastMillis = currentMillis;            // 마지막 출력 시간 갱신
    }
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();               // 전력 제어 클럭 활성화
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1); // 전압 조정
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE; // 외부 크리스탈 사용
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
    Error_Handler();                        // 오류 발생 시 핸들러 실행
  }
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK) {
    Error_Handler();                        // 오류 발생 시 핸들러 실행
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();                          // 인터럽트 비활성화
  while (1) { }                             // 무한 루프 (오류 발생 시 멈춤)
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
